package com.example.myrestfulproject1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyRestfulProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
