package com.example.myrestfulproject1.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.myrestfulproject1.exception.ResourceNotFoundException;
import com.example.myrestfulproject1.model.Business;
import com.example.myrestfulproject1.repository.BusinessRepository;

@RestController
@RequestMapping("/api/v1")
public class BusinessController {
@Autowired
private BusinessRepository businessRepository;

//create all businesss api
@GetMapping("/businesss")
public List<Business> getAllbusinesss(){
	return businessRepository.findAll();
}


//create an business
@PostMapping("/businesss")
public Business createbusiness(@Valid @RequestBody Business business) {
return businessRepository.save(business);
}
//get business
@PutMapping("/businesss/{id}")
public ResponseEntity < Business > updatebusiness(@PathVariable(value = "id") long businessId,
    @Valid @RequestBody Business businessDetails) throws ResourceNotFoundException {
    Business business = businessRepository.findById(businessId)
        .orElseThrow(() -> new ResourceNotFoundException("business not found for this id" ));

    business.setName(businessDetails.getName());
    business.setLocation(businessDetails.getLocation());
    business.setOwner(businessDetails.getOwner());
    
    return ResponseEntity.ok(business);
}

//update business
@RequestMapping("/businesss/{id}")
    public ResponseEntity < Business > updatebusinesss(@PathVariable(value = "id") long businessId,
        @Valid @RequestBody Business businessDetails) throws ResourceNotFoundException {
        Business business = businessRepository.findById(businessId)
            .orElseThrow(() -> new ResourceNotFoundException("business not found for this id"));
        return ResponseEntity.ok().body(business);

}
}

