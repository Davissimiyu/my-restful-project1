package com.example.myrestfulproject1.model;

import java.util.HashSet;

import javax.management.relation.Role;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private String Username;
	private String Password;
	
	
	public User() {
		super();
	}
	public User(String username, String password) {
		super();
		Username = username;
		Password = password;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public Role[] getRoles() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setRoles(@SuppressWarnings("rawtypes") HashSet hashSet) {
		// TODO Auto-generated method stub
		
	}
	public static Object withUsername(String string) {
		// TODO Auto-generated method stub
		return null;
	}

}
