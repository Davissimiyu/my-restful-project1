package com.example.myrestfulproject1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "businesses")
public class Business {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name ="name")
	private String name;
	@Column(name ="location")
	private String location;
	@Column(name ="owner")
	private String owner;
	public long getId() {
		return id;
	}
	
	public Business() {
		super();
	}

	public Business(long id, String name, String location, String owner) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.owner = owner;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}

}
