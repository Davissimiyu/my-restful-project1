package com.example.myrestfulproject1.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="items")
public class Item {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(name = "businessnumber")
	private int businessnumber;
	@Column(name = "name")
	private String name;
	@Column(name = "unitcost")
	private int unitCost;
	@Column(name = "quantity")
	private int quantity;
	@Column(name = "description")
	private String description;
	
	public Item() {
		super();
	}
	public Item(long id, int businessnumber, String name, int unitCost, int quantity, String description) {
		super();
		this.id = id;
		this.businessnumber = businessnumber;
		this.name = name;
		this.unitCost = unitCost;
		this.quantity = quantity;
		this.description = description;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getBusinessnumber() {
		return businessnumber;
	}
	public void setBusinessnumber(int businessnumber) {
		this.businessnumber = businessnumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUnitCost() {
		return unitCost;
	}
	public void setUnitCost(int unitCost) {
		this.unitCost = unitCost;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Item orElseThrow(Object object) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
